import { BlurView } from "expo-blur";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Tabs, usePathname } from "expo-router";
import { Icon, Label, NativeTabs } from "expo-router/unstable-native-tabs";
import { SymbolView } from "expo-symbols";
import { Feather } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View } from "react-native";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { scrollRegistry } from "@/hooks/scrollRegistry";

const AnyTrigger = NativeTabs.Trigger as any;

/** Map a tab name to its pathname segment (index lives at "/"). */
const TAB_PATHS: Record<string, string> = {
  activity: "activity",
  analytics: "analytics",
  index: "",          // home tab — pathname is "/"
  friends: "friends",
  account: "account",
};

function NativeTabLayout() {
  const pathname = usePathname();
  const { unreadNotificationCount } = useApp();
  // Derive which tab is currently showing from the pathname
  const activeSegment = pathname.split("/").filter(Boolean).pop() ?? "";

  function triggerIfActive(tab: string) {
    const expected = TAB_PATHS[tab];
    if (activeSegment === expected) {
      scrollRegistry.trigger(tab);
    }
  }

  return (
    <NativeTabs>
      <AnyTrigger
        name="activity"
        onPress={() => triggerIfActive("activity")}
        badge={unreadNotificationCount > 0 ? unreadNotificationCount : undefined}
      >
        <Icon sf={{ default: "list.bullet", selected: "list.bullet" }} />
        <Label>Activity</Label>
      </AnyTrigger>
      <AnyTrigger name="analytics" onPress={() => triggerIfActive("analytics")}>
        <Icon sf={{ default: "chart.bar", selected: "chart.bar.fill" }} />
        <Label>Stats</Label>
      </AnyTrigger>
      <AnyTrigger name="index" onPress={() => triggerIfActive("index")}>
        <Icon sf={{ default: "house", selected: "house.fill" }} />
        <Label>Groups</Label>
      </AnyTrigger>
      <AnyTrigger name="friends" onPress={() => triggerIfActive("friends")}>
        <Icon sf={{ default: "person.2", selected: "person.2.fill" }} />
        <Label>Friends</Label>
      </AnyTrigger>
      <AnyTrigger name="account" onPress={() => triggerIfActive("account")}>
        <Icon sf={{ default: "gearshape", selected: "gearshape.fill" }} />
        <Label>Account</Label>
      </AnyTrigger>
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const { colors, isDark } = useTheme();
  const { unreadNotificationCount } = useApp();
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.tabIconDefault,
        headerShown: false,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : colors.tabBar,
          borderTopWidth: 1,
          borderTopColor: colors.tabBarBorder,
          elevation: 0,
          height: isWeb ? 84 : 64,
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={100}
              tint={isDark ? "dark" : "light"}
              style={StyleSheet.absoluteFill}
            />
          ) : (
            <View
              style={[StyleSheet.absoluteFill, { backgroundColor: colors.tabBar }]}
            />
          ),
        tabBarLabelStyle: {
          fontFamily: "Inter_500Medium",
          fontSize: 11,
          marginBottom: isWeb ? 12 : 4,
        },
      }}
    >
      <Tabs.Screen
        name="activity"
        options={{
          title: "Activity",
          tabBarBadge: unreadNotificationCount > 0 ? unreadNotificationCount : undefined,
          tabBarBadgeStyle: { backgroundColor: colors.primary, fontSize: 10 },
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="list.bullet" tintColor={color} size={24} />
            ) : (
              <Feather name="activity" size={22} color={color} />
            ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => { if (navigation.isFocused()) scrollRegistry.trigger("activity"); },
        })}
      />
      <Tabs.Screen
        name="analytics"
        options={{
          title: "Stats",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="chart.bar" tintColor={color} size={24} />
            ) : (
              <Feather name="bar-chart-2" size={22} color={color} />
            ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => { if (navigation.isFocused()) scrollRegistry.trigger("analytics"); },
        })}
      />
      <Tabs.Screen
        name="index"
        options={{
          title: "Groups",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="house" tintColor={color} size={24} />
            ) : (
              <Feather name="home" size={22} color={color} />
            ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => { if (navigation.isFocused()) scrollRegistry.trigger("index"); },
        })}
      />
      {/* recurring.tsx stays in (tabs) for routing but is hidden — it redirects to /recurring (stack screen) */}
      <Tabs.Screen
        name="recurring"
        options={{ href: null }}
      />
      <Tabs.Screen
        name="friends"
        options={{
          title: "Friends",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="person.2" tintColor={color} size={24} />
            ) : (
              <Feather name="users" size={22} color={color} />
            ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => { if (navigation.isFocused()) scrollRegistry.trigger("friends"); },
        })}
      />
      <Tabs.Screen
        name="account"
        options={{
          title: "Account",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="gearshape" tintColor={color} size={24} />
            ) : (
              <Feather name="settings" size={22} color={color} />
            ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => { if (navigation.isFocused()) scrollRegistry.trigger("account"); },
        })}
      />
    </Tabs>
  );
}

export default function TabLayout() {
  if (isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}

const styles = StyleSheet.create({});

import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Avatar } from "@/components/Avatar";
import { BUILTIN_CATEGORY_CONFIG } from "@/components/CategoryIcon";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import {
  Currency,
  CURRENCY_SYMBOLS,
  RECURRING_FREQUENCY_DAYS,
  RECURRING_FREQUENCY_LABELS,
  RecurringFrequency,
  SplitType,
  computeNextOccurrences,
  useApp,
} from "@/context/AppContext";
import { CurrencyPickerModal } from "@/components/CurrencyPickerModal";
import { DatePickerField } from "@/components/DatePickerField";
import { showActionSheet, showAlert } from "@/hooks/alertStore";
import { useTheme } from "@/hooks/useTheme";
import { suggestCategory } from "@/services/ai";

const BUILTIN_CATEGORIES = [
  { value: "food", label: "Food", icon: "coffee" },
  { value: "transport", label: "Transport", icon: "navigation" },
  { value: "accommodation", label: "Stay", icon: "home" },
  { value: "entertainment", label: "Fun", icon: "film" },
  { value: "utilities", label: "Utilities", icon: "zap" },
  { value: "shopping", label: "Shopping", icon: "shopping-bag" },
  { value: "health", label: "Health", icon: "heart" },
  { value: "other", label: "Other", icon: "more-horizontal" },
] as const;

const SPLIT_TYPES: { value: SplitType; label: string; desc: string }[] = [
  { value: "equal", label: "Equal", desc: "Split evenly" },
  { value: "exact", label: "Exact", desc: "Set amounts" },
  { value: "percentage", label: "%", desc: "By percentage" },
];

export default function NewExpenseScreen() {
  const { groupId, expenseId } = useLocalSearchParams<{ groupId: string; expenseId?: string }>();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const {
    getGroupById,
    getMemberById,
    currentUser,
    addExpense,
    updateExpense,
    addRecurringExpense,
    expenses,
    customCategories,
    addCustomCategory,
  } = useApp();

  const existingExpense = expenseId ? expenses.find(e => e.id === expenseId) : undefined;
  const isEditing = !!existingExpense;
  const resolvedGroupId = existingExpense?.groupId ?? groupId ?? "";
  const group = getGroupById(resolvedGroupId);

  const [description, setDescription] = useState(existingExpense?.description ?? "");
  const [amountStr, setAmountStr] = useState(existingExpense ? String(existingExpense.amount) : "");
  const [paidById, setPaidById] = useState(existingExpense?.paidById ?? currentUser.id);
  const [category, setCategory] = useState<string>(existingExpense?.category ?? "food");
  const [autoCategory, setAutoCategory] = useState<string | null>(null);
  const [splitType, setSplitType] = useState<SplitType>(existingExpense?.splitType ?? "equal");
  const [exactAmounts, setExactAmounts] = useState<Record<string, string>>(
    existingExpense?.splitType === "exact"
      ? Object.fromEntries(existingExpense.splits.map(s => [s.memberId, String(s.amount)]))
      : {}
  );
  const [percentages, setPercentages] = useState<Record<string, string>>(
    existingExpense?.splitType === "percentage"
      ? Object.fromEntries(existingExpense.splits.map(s => [s.memberId, String(s.percentage ?? 0)]))
      : {}
  );
  const [showAddCat, setShowAddCat] = useState(false);
  const [descError, setDescError] = useState(false);
  const [amountError, setAmountError] = useState(false);
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringFrequency, setRecurringFrequency] = useState<RecurringFrequency>("monthly");
  const [customDays, setCustomDays] = useState("30");
  const [recurringDayOfWeek, setRecurringDayOfWeek] = useState<number | undefined>(undefined);
  const [recurringTimeOfDay, setRecurringTimeOfDay] = useState("09:00");
  const [endType, setEndType] = useState<"never" | "count" | "date">("never");
  const [endCount, setEndCount] = useState("10");
  const [endDateStr, setEndDateStr] = useState("");
  const [newCatName, setNewCatName] = useState("");
  const [expenseCurrency, setExpenseCurrency] = useState<Currency>(
    existingExpense?.currency ?? group?.currency ?? "USD"
  );
  const [showExpCurrencyPicker, setShowExpCurrencyPicker] = useState(false);
  const [saving, setSaving] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const amount = parseFloat(amountStr) || 0;

  function handleDismiss() {
    const dirty = isEditing
      ? (description.trim() !== (existingExpense?.description ?? "") || amount !== (existingExpense?.amount ?? 0))
      : (description.trim().length > 0 || amountStr.trim().length > 0);
    if (dirty) {
      showAlert(
        "Discard this expense?",
        isEditing
          ? "Your changes to this expense haven't been saved."
          : "You've started adding an expense but haven't saved it.",
        [
          { text: "Keep editing", style: "cancel" },
          { text: "Discard", style: "destructive", onPress: () => router.back() },
        ]
      );
      return;
    }
    router.back();
  }

  const nextOccurrences = useMemo(() => {
    if (!isRecurring) return [];
    return computeNextOccurrences({
      frequency: recurringFrequency,
      customDays: recurringFrequency === "custom" ? (parseInt(customDays) || 30) : undefined,
      dayOfWeek: recurringDayOfWeek,
      endType,
      endCount: endType === "count" ? (parseInt(endCount) || 10) : undefined,
      endDate: endType === "date" ? (endDateStr || undefined) : undefined,
      occurrenceCount: 0,
      nextDueAt: (() => {
        const d = new Date();
        const days = recurringFrequency === "custom"
          ? (parseInt(customDays) || 30)
          : RECURRING_FREQUENCY_DAYS[recurringFrequency];
        return new Date(d.getTime() + days * 24 * 60 * 60 * 1000).toISOString();
      })(),
    }, 6);
  }, [isRecurring, recurringFrequency, customDays, recurringDayOfWeek, endType, endCount, endDateStr]);
  const currencySymbol = CURRENCY_SYMBOLS[expenseCurrency] ?? expenseCurrency + " ";

  const suggestTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (suggestTimer.current) clearTimeout(suggestTimer.current);
    suggestTimer.current = setTimeout(() => {
      if (description.trim().length >= 3) {
        const result = suggestCategory(description);
        if (result.confidence === "high") {
          setCategory(result.category);
          setAutoCategory(result.category);
        }
      }
    }, 250);
    return () => { if (suggestTimer.current) clearTimeout(suggestTimer.current); };
  }, [description]);

  const members = useMemo(
    () =>
      (group?.memberIds ?? [])
        .map(id => getMemberById(id))
        .filter(Boolean) as NonNullable<ReturnType<typeof getMemberById>>[],
    [group, getMemberById]
  );

  const splits = useMemo(() => {
    if (!group) return [];
    if (splitType === "equal") {
      const share = members.length > 0 ? amount / members.length : 0;
      return members.map(m => ({
        memberId: m.id,
        amount: Math.round(share * 100) / 100,
        paid: m.id === paidById ? amount : undefined,
      }));
    }
    if (splitType === "exact") {
      return members.map(m => ({
        memberId: m.id,
        amount: parseFloat(exactAmounts[m.id] ?? "0") || 0,
        paid: m.id === paidById ? amount : undefined,
      }));
    }
    return members.map(m => {
      const pct = parseFloat(percentages[m.id] ?? "0") || 0;
      return {
        memberId: m.id,
        amount: Math.round((pct / 100) * amount * 100) / 100,
        percentage: pct,
        paid: m.id === paidById ? amount : undefined,
      };
    });
  }, [splitType, amount, members, paidById, exactAmounts, percentages]);

  const splitTotal = useMemo(() => splits.reduce((s, sp) => s + sp.amount, 0), [splits]);

  const splitValid = useMemo(() => {
    if (amount <= 0) return null;
    if (splitType === "equal") return true;
    if (splitType === "exact") return Math.abs(splitTotal - amount) < 0.01;
    if (splitType === "percentage") {
      const totalPct = members.reduce((s, m) => s + (parseFloat(percentages[m.id] ?? "0") || 0), 0);
      return Math.abs(totalPct - 100) < 0.1;
    }
    return false;
  }, [amount, splitType, splitTotal, members, percentages]);

  function adjustExact(memberId: string, delta: number) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setExactAmounts(prev => {
      const current = parseFloat(prev[memberId] ?? "0") || 0;
      const next = Math.max(0, Math.round((current + delta) * 100) / 100);
      return { ...prev, [memberId]: next.toFixed(2) };
    });
  }

  function adjustPercentage(memberId: string, delta: number) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setPercentages(prev => {
      const current = parseFloat(prev[memberId] ?? "0") || 0;
      const next = Math.max(0, Math.min(100, Math.round((current + delta) * 10) / 10));
      return { ...prev, [memberId]: next.toString() };
    });
  }

  function handleAddCustomCategory() {
    const name = newCatName.trim();
    if (!name) return;
    addCustomCategory(name);
    setCategory(name.toLowerCase());
    setAutoCategory(null);
    setNewCatName("");
    setShowAddCat(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }

  function handleSave() {
    if (saving) return;
    let hasError = false;
    if (!description.trim()) { setDescError(true); hasError = true; }
    if (amount <= 0) { setAmountError(true); hasError = true; }
    if (hasError) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }
    if (!group) return;
    if (splitValid === false) {
      const msg =
        splitType === "exact"
          ? `Amounts must add up to ${currencySymbol}${amount.toFixed(2)}. They currently total ${currencySymbol}${splitTotal.toFixed(2)}.`
          : "Percentages must add up to 100%.";
      showAlert("Split doesn't balance", msg);
      return;
    }
    setSaving(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    if (isEditing && existingExpense) {
      updateExpense(existingExpense.id, {
        description: description.trim(),
        amount,
        currency: expenseCurrency,
        paidById,
        splitType,
        splits,
        category,
      });
    } else {
      addExpense({
        groupId: group.id,
        description: description.trim(),
        amount,
        currency: expenseCurrency,
        paidById,
        splitType,
        splits,
        category,
      });
      if (isRecurring) {
        const days = recurringFrequency === "custom"
          ? Math.max(1, parseInt(customDays) || 30)
          : RECURRING_FREQUENCY_DAYS[recurringFrequency];
        const firstDue = nextOccurrences.length > 0
          ? nextOccurrences[0].toISOString()
          : new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
        addRecurringExpense({
          groupId: group.id,
          description: description.trim(),
          amount,
          currency: expenseCurrency,
          paidById,
          splitType,
          splits,
          category,
          frequency: recurringFrequency,
          ...(recurringFrequency === "custom" ? { customDays: days } : {}),
          ...(recurringDayOfWeek !== undefined ? { dayOfWeek: recurringDayOfWeek } : {}),
          timeOfDay: recurringTimeOfDay,
          endType,
          ...(endType === "count" ? { endCount: parseInt(endCount) || 10 } : {}),
          ...(endType === "date" && endDateStr ? { endDate: endDateStr } : {}),
          occurrenceCount: 0,
          nextDueAt: firstDue,
          isActive: true,
        });
      }
    }
    router.back();
  }

  if (!group) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.text }}>Group not found</Text>
      </View>
    );
  }

  const allCategories = [
    ...BUILTIN_CATEGORIES,
    ...customCategories.map(c => ({
      value: c,
      label: c.charAt(0).toUpperCase() + c.slice(1),
      icon: "tag" as const,
    })),
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.headerBg }]}>
        <Pressable onPress={handleDismiss} hitSlop={8}>
          <Feather name="x" size={24} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{isEditing ? "Edit Expense" : "Add Expense"}</Text>
        <View style={styles.headerRight}>
          <Pressable
            style={[styles.saveBtn, { backgroundColor: colors.primary, opacity: saving ? 0.6 : 1 }]}
            onPress={handleSave}
            disabled={saving}
          >
            <Text style={styles.saveBtnText}>Save</Text>
          </Pressable>
        </View>
      </View>

      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.content, { paddingBottom: Platform.OS === "web" ? 134 : 40 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
      >
        <View>
          <View style={[
            styles.amountCard,
            { backgroundColor: colors.surface },
            amountError && { borderWidth: 2, borderColor: colors.danger },
          ]}>
            <Pressable
              onPress={() => setShowExpCurrencyPicker(true)}
              style={[styles.expCurrencyChip, { backgroundColor: colors.primaryLight ?? colors.surface, borderColor: colors.primary }]}
            >
              <Text style={[styles.expCurrencyChipText, { color: colors.primary }]}>{expenseCurrency}</Text>
              <Feather name="chevron-down" size={11} color={colors.primary} />
            </Pressable>
            <View style={styles.amountRow}>
              <Text style={[styles.currencySymbol, { color: amountError ? colors.danger : colors.primary }]}>
                {currencySymbol}
              </Text>
              <TextInput
                style={[styles.amountInput, { color: colors.text }]}
                placeholder="0.00"
                placeholderTextColor={colors.textTertiary}
                value={amountStr}
                onChangeText={t => { setAmountStr(t); if (parseFloat(t) > 0) setAmountError(false); }}
                keyboardType="decimal-pad"
                autoFocus
              />
            </View>
            {group && expenseCurrency !== group.currency && (
              <Text style={[styles.expCurrencyNote, { color: colors.textTertiary }]}>
                Balances converted to {group.currency}
              </Text>
            )}
          </View>
          {amountError && (
            <Text style={[styles.fieldErrorHint, { color: colors.danger }]}>
              Please enter a cost amount
            </Text>
          )}
        </View>

        <View style={styles.descRow}>
          <View style={{ flex: 1 }}>
            <TextInput
              style={[
                styles.descriptionInput,
                { color: colors.text, backgroundColor: colors.surface, flex: 1 },
                descError
                  ? { borderColor: colors.danger, borderWidth: 2 }
                  : { borderColor: colors.border, borderWidth: 1 },
              ]}
              placeholder="What's this for? *"
              placeholderTextColor={descError ? colors.danger : colors.textTertiary}
              value={description}
              onChangeText={t => { setDescription(t); if (t.trim()) setDescError(false); }}
            />
            {descError && (
              <Text style={[styles.fieldErrorHint, { color: colors.danger }]}>
                Please add a description
              </Text>
            )}
          </View>
        </View>

        {/* Recurring toggle — only when creating, not editing */}
        {!isEditing && (
          <View style={styles.recurringSection}>
            <View style={[styles.recurringRow, {
              backgroundColor: isRecurring ? colors.primaryLight : colors.surface,
              borderColor: isRecurring ? colors.primary : colors.primary + "50",
              borderWidth: 1.5,
            }]}>
              <View style={[styles.recurringIconWrap, { backgroundColor: isRecurring ? colors.primary : colors.primaryLight }]}>
                <Feather name="repeat" size={15} color={isRecurring ? "#fff" : colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.recurringLabel, { color: isRecurring ? colors.primary : colors.text }]}>
                  Repeat this expense
                </Text>
                <Text style={[styles.recurringSubHint, { color: isRecurring ? colors.primary + "aa" : colors.textTertiary }]}>
                  {isRecurring ? `${RECURRING_FREQUENCY_LABELS[recurringFrequency]} schedule` : "Create a recurring payment"}
                </Text>
              </View>
              <Switch
                value={isRecurring}
                onValueChange={v => {
                  setIsRecurring(v);
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
                style={{ marginLeft: "auto" }}
              />
            </View>
            {isRecurring && (
              <View style={styles.freqRow}>
                {(Object.entries(RECURRING_FREQUENCY_LABELS) as [RecurringFrequency, string][]).map(([val, label]) => (
                  <Pressable
                    key={val}
                    style={[
                      styles.freqChip,
                      {
                        backgroundColor: recurringFrequency === val ? colors.primary : colors.surface,
                        borderColor: recurringFrequency === val ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => {
                      setRecurringFrequency(val);
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    }}
                  >
                    <Text style={[
                      styles.freqChipText,
                      { color: recurringFrequency === val ? "#fff" : colors.textSecondary },
                    ]}>
                      {label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
            {isRecurring && recurringFrequency === "custom" && (
              <View style={[styles.customDaysRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.customDaysLabel, { color: colors.text }]}>Every</Text>
                <TextInput
                  style={[styles.customDaysInput, { color: colors.text, backgroundColor: colors.inputBg, borderColor: colors.border }]}
                  value={customDays}
                  onChangeText={t => setCustomDays(t.replace(/[^0-9]/g, ""))}
                  keyboardType="number-pad"
                  maxLength={3}
                  selectTextOnFocus
                />
                <Text style={[styles.customDaysLabel, { color: colors.text }]}>days</Text>
              </View>
            )}
            {/* Day-of-week picker (weekly / biweekly only) */}
            {isRecurring && (recurringFrequency === "weekly" || recurringFrequency === "biweekly") && (
              <View style={styles.recurringSubSection}>
                <Text style={[styles.recurringSubLabel, { color: colors.textSecondary }]}>Which day?</Text>
                <View style={styles.dayPickerRow}>
                  {["S","M","T","W","T","F","S"].map((d, idx) => (
                    <Pressable
                      key={idx}
                      style={[
                        styles.dayChip,
                        {
                          backgroundColor: recurringDayOfWeek === idx ? colors.primary : colors.surface,
                          borderColor: recurringDayOfWeek === idx ? colors.primary : colors.border,
                        },
                      ]}
                      onPress={() => {
                        setRecurringDayOfWeek(recurringDayOfWeek === idx ? undefined : idx);
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      }}
                    >
                      <Text style={[styles.dayChipText, { color: recurringDayOfWeek === idx ? "#fff" : colors.textSecondary }]}>
                        {d}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}

            {/* Time of day picker */}
            {isRecurring && (
              <View style={styles.recurringSubSection}>
                <Text style={[styles.recurringSubLabel, { color: colors.textSecondary }]}>Time of day</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                  {[
                    { label: "Morning", sub: "9:00 am",  value: "09:00", icon: "☀️" },
                    { label: "Noon",    sub: "12:00 pm", value: "12:00", icon: "🌤️" },
                    { label: "Afternoon",sub: "3:00 pm", value: "15:00", icon: "⛅️" },
                    { label: "Evening", sub: "6:00 pm",  value: "18:00", icon: "🌇" },
                    { label: "Night",   sub: "10:00 pm", value: "22:00", icon: "🌙" },
                  ].map(t => {
                    const active = recurringTimeOfDay === t.value;
                    return (
                      <Pressable
                        key={t.value}
                        style={[
                          styles.timeChip,
                          {
                            backgroundColor: active ? colors.primary : colors.surface,
                            borderColor: active ? colors.primary : colors.border,
                          },
                        ]}
                        onPress={() => { setRecurringTimeOfDay(t.value); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                      >
                        <Text style={styles.timeChipEmoji}>{t.icon}</Text>
                        <Text style={[styles.timeChipLabel, { color: active ? "#fff" : colors.text }]}>{t.label}</Text>
                        <Text style={[styles.timeChipSub, { color: active ? "rgba(255,255,255,0.75)" : colors.textTertiary }]}>{t.sub}</Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>
            )}

            {/* End condition */}
            {isRecurring && (
              <View style={styles.recurringSubSection}>
                <Text style={[styles.recurringSubLabel, { color: colors.textSecondary }]}>Ends</Text>
                <View style={styles.endTypeRow}>
                  {(["never", "count", "date"] as const).map(et => (
                    <Pressable
                      key={et}
                      style={[
                        styles.endTypeBtn,
                        {
                          backgroundColor: endType === et ? colors.primary : colors.surface,
                          borderColor: endType === et ? colors.primary : colors.border,
                        },
                      ]}
                      onPress={() => { setEndType(et); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                    >
                      <Text style={[styles.endTypeBtnText, { color: endType === et ? "#fff" : colors.textSecondary }]}>
                        {et === "never" ? "Forever" : et === "count" ? "After N times" : "Until date"}
                      </Text>
                    </Pressable>
                  ))}
                </View>
                {endType === "count" && (
                  <View style={[styles.customDaysRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                    <Text style={[styles.customDaysLabel, { color: colors.text }]}>After</Text>
                    <TextInput
                      style={[styles.customDaysInput, { color: colors.text, backgroundColor: colors.inputBg, borderColor: colors.border }]}
                      value={endCount}
                      onChangeText={t => setEndCount(t.replace(/[^0-9]/g, ""))}
                      keyboardType="number-pad"
                      maxLength={3}
                      selectTextOnFocus
                    />
                    <Text style={[styles.customDaysLabel, { color: colors.text }]}>occurrences</Text>
                  </View>
                )}
                {endType === "date" && (
                  <DatePickerField
                    label="End date"
                    value={endDateStr}
                    onChange={setEndDateStr}
                    colors={colors}
                  />
                )}
              </View>
            )}

            {/* Upcoming payments preview strip */}
            {isRecurring && nextOccurrences.length > 0 && (
              <View style={styles.recurringSubSection}>
                <Text style={[styles.recurringSubLabel, { color: colors.textSecondary }]}>
                  Upcoming payments ({nextOccurrences.length}{endType === "never" ? "+" : ""})
                </Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                  {nextOccurrences.map((d, i) => (
                    <View
                      key={i}
                      style={[
                        styles.previewCard,
                        {
                          backgroundColor: i === 0 ? colors.primary : colors.surface,
                          borderColor: i === 0 ? colors.primary : colors.border,
                        },
                      ]}
                    >
                      <Text style={[styles.previewCardMonth, { color: i === 0 ? "rgba(255,255,255,0.75)" : colors.textTertiary }]}>
                        {d.toLocaleDateString("en", { month: "short" }).toUpperCase()}
                      </Text>
                      <Text style={[styles.previewCardDay, { color: i === 0 ? "#fff" : colors.text }]}>
                        {d.getDate()}
                      </Text>
                      <Text style={[styles.previewCardWeekday, { color: i === 0 ? "rgba(255,255,255,0.75)" : colors.textTertiary }]}>
                        {d.toLocaleDateString("en", { weekday: "short" })}
                      </Text>
                    </View>
                  ))}
                </ScrollView>
              </View>
            )}

            {isRecurring && (
              <Text style={[styles.recurringNote, { color: colors.textTertiary }]}>
                Added once now, then automatically
                {recurringFrequency === "custom"
                  ? ` every ${parseInt(customDays) || 30} day${(parseInt(customDays) || 30) === 1 ? "" : "s"}`
                  : ` ${RECURRING_FREQUENCY_LABELS[recurringFrequency].toLowerCase()}`}
                {recurringDayOfWeek !== undefined && (recurringFrequency === "weekly" || recurringFrequency === "biweekly")
                  ? ` on ${["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][recurringDayOfWeek]}s`
                  : ""}
                {endType === "count" ? `, ${endCount} times total` : endType === "date" && endDateStr ? `, until ${endDateStr.split("-").reverse().join("-")}` : ""}.
              </Text>
            )}
          </View>
        )}

        <View style={styles.sectionLabelRow}>
          <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Category</Text>
          {autoCategory && autoCategory === category && (
            <View style={[styles.autoBadge, { backgroundColor: colors.primaryLight }]}>
              <Feather name="zap" size={10} color={colors.primary} />
              <Text style={[styles.autoBadgeText, { color: colors.primary }]}>Auto</Text>
            </View>
          )}
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catRow}>
          {allCategories.map(c => {
            const isSelected = category === c.value;
            const config = BUILTIN_CATEGORY_CONFIG[c.value];
            return (
              <Pressable
                key={c.value}
                style={[
                  styles.catChip,
                  {
                    backgroundColor: isSelected ? colors.primary : colors.surface,
                    borderColor: isSelected ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => { setCategory(c.value); setAutoCategory(null); }}
              >
                <Feather
                  name={(config?.icon ?? "tag") as any}
                  size={14}
                  color={isSelected ? "#fff" : (config?.color ?? colors.textSecondary)}
                />
                <Text style={[styles.catLabel, { color: isSelected ? "#fff" : colors.text }]}>
                  {c.label}
                </Text>
              </Pressable>
            );
          })}

          {/* Add custom category */}
          {showAddCat ? (
            <View style={[styles.addCatWrap, { borderColor: colors.primary, backgroundColor: colors.primaryLight }]}>
              <TextInput
                style={[styles.addCatInput, { color: colors.text }]}
                placeholder="Category name"
                placeholderTextColor={colors.textTertiary}
                value={newCatName}
                onChangeText={setNewCatName}
                autoFocus
                onSubmitEditing={handleAddCustomCategory}
                returnKeyType="done"
              />
              <Pressable onPress={handleAddCustomCategory}>
                <Feather name="check" size={16} color={colors.primary} />
              </Pressable>
              <Pressable onPress={() => { setShowAddCat(false); setNewCatName(""); }}>
                <Feather name="x" size={16} color={colors.textTertiary} />
              </Pressable>
            </View>
          ) : (
            <Pressable
              style={[styles.catChip, { borderColor: colors.border, borderStyle: "dashed", backgroundColor: "transparent" }]}
              onPress={() => setShowAddCat(true)}
            >
              <Feather name="plus" size={14} color={colors.textTertiary} />
              <Text style={[styles.catLabel, { color: colors.textTertiary }]}>Add</Text>
            </Pressable>
          )}
        </ScrollView>

        <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Paid by</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.paidByRow}>
          {members.map(m => (
            <Pressable
              key={m.id}
              style={[
                styles.paidByChip,
                {
                  backgroundColor: paidById === m.id ? colors.primary : colors.surface,
                  borderColor: paidById === m.id ? colors.primary : colors.border,
                },
              ]}
              onPress={() => setPaidById(m.id)}
            >
              <Avatar name={m.name} color={m.id === paidById ? "#fff" : m.avatarColor} size={24} />
              <Text style={[styles.paidByLabel, { color: paidById === m.id ? "#fff" : colors.text }]}>
                {m.isCurrentUser ? "You" : m.name.split(" ")[0]}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Split</Text>
        <View style={[styles.splitTypeRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {SPLIT_TYPES.map(t => (
            <Pressable
              key={t.value}
              style={[
                styles.splitTypeBtn,
                splitType === t.value && { backgroundColor: colors.primary },
              ]}
              onPress={() => setSplitType(t.value)}
            >
              <Text style={[styles.splitTypeLabel, { color: splitType === t.value ? "#fff" : colors.text }]}>
                {t.label}
              </Text>
              <Text style={[styles.splitTypeDesc, { color: splitType === t.value ? "rgba(255,255,255,0.7)" : colors.textSecondary }]}>
                {t.desc}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.splitDetails}>
          {members.map(m => {
            const split = splits.find(s => s.memberId === m.id);
            return (
              <View key={m.id} style={[styles.splitRow, { backgroundColor: colors.surface }]}>
                <Avatar name={m.name} color={m.avatarColor} size={32} />
                <Text style={[styles.splitName, { color: colors.text }]}>
                  {m.isCurrentUser ? "You" : m.name.split(" ")[0]}
                </Text>
                {splitType === "equal" ? (
                  <Text style={[styles.splitAmount, { color: colors.textSecondary }]}>
                    {currencySymbol}{(split?.amount ?? 0).toFixed(2)}
                  </Text>
                ) : splitType === "exact" ? (
                  <View style={styles.stepperWrap}>
                    <Pressable
                      style={[styles.stepperBtn, { backgroundColor: colors.primaryLight, borderColor: colors.border }]}
                      onPress={() => adjustExact(m.id, -1)}
                    >
                      <Feather name="minus" size={14} color={colors.primary} />
                    </Pressable>
                    <TextInput
                      style={[styles.splitInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.inputBg }]}
                      placeholder="0.00"
                      placeholderTextColor={colors.textTertiary}
                      value={exactAmounts[m.id] ?? ""}
                      onChangeText={v => setExactAmounts(prev => ({ ...prev, [m.id]: v }))}
                      keyboardType="decimal-pad"
                    />
                    <Pressable
                      style={[styles.stepperBtn, { backgroundColor: colors.primaryLight, borderColor: colors.border }]}
                      onPress={() => adjustExact(m.id, 1)}
                    >
                      <Feather name="plus" size={14} color={colors.primary} />
                    </Pressable>
                  </View>
                ) : (
                  <View style={styles.stepperWrap}>
                    <Pressable
                      style={[styles.stepperBtn, { backgroundColor: colors.primaryLight, borderColor: colors.border }]}
                      onPress={() => adjustPercentage(m.id, -5)}
                    >
                      <Feather name="minus" size={14} color={colors.primary} />
                    </Pressable>
                    <View style={styles.pctInputWrap}>
                      <TextInput
                        style={[styles.splitInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.inputBg }]}
                        placeholder="0"
                        placeholderTextColor={colors.textTertiary}
                        value={percentages[m.id] ?? ""}
                        onChangeText={v => setPercentages(prev => ({ ...prev, [m.id]: v }))}
                        keyboardType="decimal-pad"
                      />
                      <Text style={[styles.pctLabel, { color: colors.textSecondary }]}>%</Text>
                    </View>
                    <Pressable
                      style={[styles.stepperBtn, { backgroundColor: colors.primaryLight, borderColor: colors.border }]}
                      onPress={() => adjustPercentage(m.id, 5)}
                    >
                      <Feather name="plus" size={14} color={colors.primary} />
                    </Pressable>
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {splitType !== "equal" && amount > 0 && (
          <View style={[
            styles.validationRow,
            {
              backgroundColor: splitValid ? colors.successLight : colors.dangerLight,
              borderColor: splitValid ? colors.success : colors.danger,
            },
          ]}>
            <Feather
              name={splitValid ? "check-circle" : "alert-circle"}
              size={16}
              color={splitValid ? colors.success : colors.danger}
            />
            <Text style={[styles.validationText, { color: splitValid ? colors.success : colors.danger }]}>
              {splitType === "exact"
                ? splitValid
                  ? `Splits add up to ${currencySymbol}${amount.toFixed(2)} ✓`
                  : `${currencySymbol}${splitTotal.toFixed(2)} of ${currencySymbol}${amount.toFixed(2)} assigned`
                : (() => {
                    const totalPct = members.reduce(
                      (s, m) => s + (parseFloat(percentages[m.id] ?? "0") || 0),
                      0
                    );
                    return splitValid
                      ? `Percentages add up to 100% ✓`
                      : `${totalPct.toFixed(1)}% of 100% assigned`;
                  })()}
            </Text>
          </View>
        )}

      </KeyboardAwareScrollViewCompat>

      <CurrencyPickerModal
        visible={showExpCurrencyPicker}
        value={expenseCurrency}
        onChange={(c: Currency) => { setExpenseCurrency(c); setShowExpCurrencyPicker(false); }}
        onClose={() => setShowExpCurrencyPicker(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  saveBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
  saveBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  content: { padding: 20, gap: 14 },
  amountCard: {
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 20,
    borderRadius: 20,
    gap: 6,
  },
  amountRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  expCurrencyChip: {
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1,
  },
  expCurrencyChipText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  expCurrencyNote: { fontSize: 12, fontFamily: "Inter_400Regular" },
  currencySymbol: { fontSize: 36, fontFamily: "Inter_700Bold" },
  amountInput: { fontSize: 52, fontFamily: "Inter_700Bold", minWidth: 120, textAlign: "center" },
  descRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  descriptionInput: {
    height: 52,
    borderRadius: 14,
    paddingHorizontal: 16,
    fontSize: 16,
    fontFamily: "Inter_400Regular",
    borderWidth: 1,
  },
  sectionLabelRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  sectionLabel: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  autoBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 6,
  },
  autoBadgeText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  catRow: { gap: 8, paddingVertical: 4 },
  catChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    gap: 6,
  },
  catLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  addCatWrap: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
    gap: 8,
  },
  addCatInput: { fontSize: 13, fontFamily: "Inter_400Regular", minWidth: 90 },
  paidByRow: { gap: 8, paddingVertical: 4 },
  paidByChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    gap: 8,
  },
  paidByLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  splitTypeRow: {
    flexDirection: "row",
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
  },
  splitTypeBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  splitTypeLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  splitTypeDesc: { fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 2 },
  splitDetails: { gap: 10 },
  splitRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 14,
    gap: 12,
  },
  splitName: { flex: 1, fontSize: 14, fontFamily: "Inter_500Medium" },
  splitAmount: { fontSize: 14, fontFamily: "Inter_500Medium" },
  stepperWrap: { flexDirection: "row", alignItems: "center", gap: 6 },
  stepperBtn: {
    width: 30,
    height: 30,
    borderRadius: 8,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  splitInput: {
    width: 70,
    height: 36,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  pctInputWrap: { flexDirection: "row", alignItems: "center", gap: 3 },
  pctLabel: { fontSize: 14, fontFamily: "Inter_500Medium" },
  validationRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  validationText: { fontSize: 13, fontFamily: "Inter_500Medium", flex: 1 },
  fieldErrorHint: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 5,
    marginLeft: 4,
  },
  recurringSection: { gap: 10 },
  recurringRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1.5,
  },
  recurringIconWrap: {
    width: 32, height: 32, borderRadius: 10,
    alignItems: "center", justifyContent: "center", flexShrink: 0,
  },
  recurringLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  recurringSubHint: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 1 },
  freqRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  freqChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  freqChipText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  customDaysRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    alignSelf: "flex-start",
  },
  customDaysLabel: { fontSize: 15, fontFamily: "Inter_400Regular" },
  customDaysInput: {
    width: 60,
    height: 38,
    borderRadius: 8,
    borderWidth: 1,
    textAlign: "center",
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
  },
  recurringNote: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
  recurringSubSection: { gap: 8, marginTop: 4 },
  recurringSubLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 0.6 },
  dayPickerRow: { flexDirection: "row", gap: 6 },
  dayChip: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  dayChipText: { fontSize: 12, fontFamily: "Inter_700Bold" },
  timeChip: { alignItems: "center", paddingHorizontal: 14, paddingVertical: 10, borderRadius: 14, borderWidth: 1, gap: 2, minWidth: 72 },
  timeChipEmoji: { fontSize: 18 },
  timeChipLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  timeChipSub: { fontSize: 10, fontFamily: "Inter_400Regular" },
  endTypeRow: { flexDirection: "row", gap: 6 },
  endTypeBtn: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 10, borderWidth: 1 },
  endTypeBtnText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  previewCard: { alignItems: "center", paddingHorizontal: 14, paddingVertical: 12, borderRadius: 14, borderWidth: 1, gap: 2, minWidth: 60 },
  previewCardMonth: { fontSize: 10, fontFamily: "Inter_600SemiBold", letterSpacing: 0.5 },
  previewCardDay: { fontSize: 22, fontFamily: "Inter_700Bold" },
  previewCardWeekday: { fontSize: 10, fontFamily: "Inter_400Regular" },
});
